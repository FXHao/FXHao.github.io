---
layout: page
title: 关于我 
---

一个 iOS SDK 开发者，喜欢研究一些新技术。
<p>
平时喜欢整理个人博客，逛逛技术论坛。
<p>
了解一些 前端 基本概念和 Python 的简单用法。

<p>

<h3> 我们的博客 </h3>  

<p>

是的，这个博客是我们大家的，目前已经有很大一部分人在使用我的博客模板了，我也很高兴大家使用我的模板。

<p>

如果你想搭建一个跟我一样的博客，可以看我的 
<a href="/2016/10/jekyll_tutorials1/"> Jekyll 搭建个人博客 </a>
教程

<p>

有关于博客主题的建议和意见都可以提给我，让我们一起来打造一个精美的主题吧~ 

<p> 

博客源码在 <a target="_blank" href='https://github.com/leopardpan/leopardpan.github.io/'>Github</a> 上，你的 Star 是我更新的动力，谢谢~

<p> 

<p> 

<p> 


{% include comments.html %}

